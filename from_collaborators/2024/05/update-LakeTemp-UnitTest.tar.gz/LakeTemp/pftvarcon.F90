module pftvarcon

  !-----------------------------------------------------------------------
  ! !DESCRIPTION:
  ! Module containing vegetation constants and method to
  ! read and initialize vegetation (PFT) constants.
  !
  ! !USES:
  #define masterproc 1
  use shr_kind_mod, only : r8 => shr_kind_r8
  !#py use shr_log_mod , only : errMsg => shr_log_errMsg
  !#py use abortutils  , only : endrun
  use elm_varpar  , only : mxpft, numrad, ivis, inir, cft_lb, cft_ub
  use elm_varpar  , only:  mxpft_nc
  use elm_varctl  , only : iulog, use_vertsoilc
  use elm_varpar  , only : nlevdecomp_full, nsoilorder
  use elm_varctl  , only : nu_com
  !
  ! !PUBLIC TYPES:
  implicit none
  save
  !
  ! Vegetation type constants
  !
  integer :: noveg                  !value for not vegetated
  integer :: ndllf_evr_tmp_tree     !value for Needleleaf evergreen temperate tree
  integer :: ndllf_evr_brl_tree     !value for Needleleaf evergreen boreal tree
  integer :: ndllf_dcd_brl_tree     !value for Needleleaf deciduous boreal tree
  integer :: nbrdlf_evr_trp_tree    !value for Broadleaf evergreen tropical tree
  integer :: nbrdlf_evr_tmp_tree    !value for Broadleaf evergreen temperate tree
  integer :: nbrdlf_dcd_trp_tree    !value for Broadleaf deciduous tropical tree
  integer :: nbrdlf_dcd_tmp_tree    !value for Broadleaf deciduous temperate tree
  integer :: nbrdlf_dcd_brl_tree    !value for Broadleaf deciduous boreal tree
  integer :: ntree                  !value for last type of tree
  integer :: nbrdlf_evr_shrub       !value for Broadleaf evergreen shrub
  integer :: nbrdlf_dcd_tmp_shrub   !value for Broadleaf deciduous temperate shrub
  integer :: nbrdlf_dcd_brl_shrub   !value for Broadleaf deciduous boreal shrub
  integer :: nc3_arctic_grass       !value for C3 arctic grass
  integer :: nc3_nonarctic_grass    !value for C3 non-arctic grass
  integer :: nc4_grass              !value for C4 grass
  integer :: npcropmin              !value for first crop
  integer :: nppercropmin           !value for first perennial crop
  integer :: ncorn                  !value for corn, rain fed (rf)
  integer :: ncornirrig             !value for corn, irrigated (ir)
  integer :: nscereal               !value for spring temperate cereal (rf)
  integer :: nscerealirrig          !value for spring temperate cereal (ir)
  integer :: nwcereal               !value for winter temperate cereal (rf)
  integer :: nwcerealirrig          !value for winter temperate cereal (ir)
  integer :: nsoybean               !value for soybean (rf)
  integer :: nsoybeanirrig          !value for soybean (ir)
  integer :: npcropmax              !value for last prognostic crop in list
  integer :: nppercropmax           !value for last prognostic perennial crop in list
  integer :: nc3crop                !value for generic crop (rf)
  integer :: nc3irrig               !value for irrigated generic crop (ir)

  integer :: ncassava               !value for cassava, rain fed (rf)
  integer :: ncassavairrig          !value for cassava, irrigated (ir)
  integer :: ncotton                !value for cotton, rain fed (rf)
  integer :: ncottonirrig           !value for cotton, irrigated (ir)
  integer :: nfoddergrass           !value for foddergrass, rain fed (rf)
  integer :: nfoddergrassirrig      !value for foddergrass, irrigated (ir)
  integer :: noilpalm               !value for oilpalm, rain fed (rf)
  integer :: noilpalmirrig          !value for oilpalm, irrigated (ir)
  integer :: nograins               !value for other grains, rain fed (rf)
  integer :: nograinsirrig          !value for other grains, irrigated (ir)
  integer :: nrapeseed              !value for rapeseed, rain fed (rf)
  integer :: nrapeseedirrig         !value for rapeseed, irrigated (ir)
  integer :: nrice                  !value for rice, rain fed (rf)
  integer :: nriceirrig             !value for rice, irrigated (ir)
  integer :: nrtubers               !value for root tubers, rain fed (rf)
  integer :: nrtubersirrig          !value for root tubers, irrigated (ir)
  integer :: nsugarcane             !value for sugarcane, rain fed (rf)
  integer :: nsugarcaneirrig        !value for sugarcane, irrigated (ir)  
  integer :: nmiscanthus            !value for miscanthus, rain fed (rf)
  integer :: nmiscanthusirrig       !value for miscanthus, irrigated (ir)
  integer :: nswitchgrass           !value for switchgrass, rain fed (rf)
  integer :: nswitchgrassirrig      !value for switchgrass, irrigated (ir)
  integer :: npoplar                !value for poplar, rain fed (rf)
  integer :: npoplarirrig           !value for poplar, irrigated (ir)
  integer :: nwillow                !value for willow, rain fed (rf)
  integer :: nwillowirrig           !value for willow, irrigated (ir)  
  

  !$acc declare create(noveg               )
  !$acc declare create(ndllf_evr_tmp_tree  )
  !$acc declare create(ndllf_evr_brl_tree  )
  !$acc declare create(ndllf_dcd_brl_tree  )
  !$acc declare create(nbrdlf_evr_trp_tree )
  !$acc declare create(nbrdlf_evr_tmp_tree )
  !$acc declare create(nbrdlf_dcd_trp_tree )
  !$acc declare create(nbrdlf_dcd_tmp_tree )
  !$acc declare create(nbrdlf_dcd_brl_tree )
  !$acc declare create(ntree               )
  !$acc declare create(nbrdlf_evr_shrub    )
  !$acc declare create(nbrdlf_dcd_tmp_shrub)
  !$acc declare create(nbrdlf_dcd_brl_shrub)
  !$acc declare create(nc3_arctic_grass    )
  !$acc declare create(nc3_nonarctic_grass )
  !$acc declare create(nc4_grass           )
  !$acc declare create(npcropmin           )
  !$acc declare create(nppercropmin        )
  !$acc declare create(ncorn               )
  !$acc declare create(ncornirrig          )
  !$acc declare create(nscereal            )
  !$acc declare create(nscerealirrig       )
  !$acc declare create(nwcereal            )
  !$acc declare create(nwcerealirrig       )
  !$acc declare create(nsoybean            )
  !$acc declare create(nsoybeanirrig       )
  !$acc declare create(npcropmax           )
  !$acc declare create(nc3crop             )
  !$acc declare create(nc3irrig            )

  ! Number of crop functional types actually used in the model. This includes each CFT for
  ! which is_pft_known_to_model is true. Note that this includes irrigated crops even if
  ! irrigation is turned off in this run: it just excludes crop types that aren't handled
  ! at all, as given by the mergetoelmpft list.
  integer :: num_cfts_known_to_model
  !$acc declare create(num_cfts_known_to_model)

  real(r8), allocatable :: dleaf(:)       !characteristic leaf dimension (m)
  real(r8), allocatable :: c3psn(:)       !photosynthetic pathway: 0. = c4, 1. = c3
  real(r8), allocatable :: xl(:)          !leaf/stem orientation index
  real(r8), allocatable :: rhol(:,:)      !leaf reflectance: 1=vis, 2=nir
  real(r8), allocatable :: rhos(:,:)      !stem reflectance: 1=vis, 2=nir
  real(r8), allocatable :: taul(:,:)      !leaf transmittance: 1=vis, 2=nir
  real(r8), allocatable :: taus(:,:)      !stem transmittance: 1=vis, 2=nir
  real(r8), allocatable :: z0mr(:)        !ratio of momentum roughness length to canopy top height (-)
  real(r8), allocatable :: displar(:)     !ratio of displacement height to canopy top height (-)
  real(r8), allocatable :: roota_par(:)   !CLM rooting distribution parameter [1/m]
  real(r8), allocatable :: rootb_par(:)   !CLM rooting distribution parameter [1/m]
  real(r8), allocatable :: crop(:)        !crop pft: 0. = not crop, 1. = crop pft
  real(r8), allocatable :: percrop(:)     !perennial crop pft: 0. = not annual crop, 1. = perennial crop pft
  real(r8), allocatable :: irrigated(:)   !irrigated pft: 0. = not, 1. = irrigated
  real(r8), allocatable :: smpso(:)       !soil water potential at full stomatal opening (mm)
  real(r8), allocatable :: smpsc(:)       !soil water potential at full stomatal closure (mm)
  real(r8), allocatable :: fnitr(:)       !foliage nitrogen limitation factor (-)

  ! begin new pft parameters for CN code
  real(r8), allocatable :: slatop(:)      !SLA at top of canopy [m^2/gC]
  real(r8), allocatable :: dsladlai(:)    !dSLA/dLAI [m^2/gC]
  real(r8), allocatable :: leafcn(:)      !leaf C:N [gC/gN]
  real(r8), allocatable :: flnr(:)        !fraction of leaf N in Rubisco [no units]
  real(r8), allocatable :: woody(:)       !woody lifeform flag (0 or 1)
  real(r8), allocatable :: lflitcn(:)     !leaf litter C:N (gC/gN)
  real(r8), allocatable :: frootcn(:)     !fine root C:N (gC/gN)
  real(r8), allocatable :: livewdcn(:)    !live wood (phloem and ray parenchyma) C:N (gC/gN)
  real(r8), allocatable :: deadwdcn(:)    !dead wood (xylem and heartwood) C:N (gC/gN)
  real(r8), allocatable :: grperc(:)      !growth respiration parameter
  real(r8), allocatable :: grpnow(:)      !growth respiration parameter
  real(r8), allocatable :: rootprof_beta(:) !CLM rooting distribution parameter for C and N inputs [unitless]

  ! add pft dependent parameters for phosphorus -X.YANG
  real(r8), allocatable :: leafcp(:)      !leaf C:P [gC/gP]
  real(r8), allocatable :: lflitcp(:)     !leaf litter C:P (gC/gP)
  real(r8), allocatable :: frootcp(:)     !fine root C:P (gC/gP)
  real(r8), allocatable :: livewdcp(:)    !live wood (phloem and ray parenchyma) C:P (gC/gP)
  real(r8), allocatable :: deadwdcp(:)    !dead wood (xylem and heartwood) C:P (gC/gP)

  !$acc declare create(dleaf(:)    )
  !$acc declare create(c3psn(:)    )
  !$acc declare create(xl(:)       )
  !$acc declare create(rhol(:,:)   )
  !$acc declare create(rhos(:,:)   )
  !$acc declare create(taul(:,:)   )
  !$acc declare create(taus(:,:)   )
  !$acc declare create(z0mr(:)     )
  !$acc declare create(displar(:)  )
  !$acc declare create(roota_par(:))
  !$acc declare create(rootb_par(:))
  !$acc declare create(crop(:)     )
  !$acc declare create(irrigated(:))
  !$acc declare create(smpso(:)    )
  !$acc declare create(smpsc(:)    )
  !$acc declare create(fnitr(:)    )
  !$acc declare create(slatop(:)      )
  !$acc declare create(dsladlai(:)    )
  !$acc declare create(leafcn(:)      )
  !$acc declare create(flnr(:)        )
  !$acc declare create(woody(:)       )
  !$acc declare create(lflitcn(:)     )
  !$acc declare create(frootcn(:)     )
  !$acc declare create(livewdcn(:)    )
  !$acc declare create(deadwdcn(:)    )
  !$acc declare create(grperc(:)      )
  !$acc declare create(grpnow(:)      )
  !$acc declare create(rootprof_beta(:))
  !$acc declare create(leafcp(:)  )
  !$acc declare create(lflitcp(:) )
  !$acc declare create(frootcp(:) )
  !$acc declare create(livewdcp(:))
  !$acc declare create(deadwdcp(:))
  !$acc declare create(percrop(:) )
  ! for crop

  ! These arrays give information about the merge of unused crop types to the types CLM
  ! knows about. mergetoelmpft(m) gives the crop type that CLM uses to simulate input
  ! type m (and mergetoelmpft(m) == m implies that CLM simulates crop type m
  ! directly). is_pft_known_to_model(m) is true if CLM simulates crop type m, and false
  ! otherwise. Note that these do NOT relate to whether irrigation is on or off in a
  ! given simulation - that is handled separately.
  integer , allocatable :: mergetoelmpft         (:)
  logical , allocatable :: is_pft_known_to_model (:)

  real(r8), allocatable :: graincn(:)      !grain C:N (gC/gN)
  real(r8), allocatable :: graincp(:)      !grain C:N (gC/gN)
  real(r8), allocatable :: mxtmp(:)        !parameter used in accFlds
  real(r8), allocatable :: baset(:)        !parameter used in accFlds
  real(r8), allocatable :: declfact(:)     !parameter used in CNAllocation
  real(r8), allocatable :: bfact(:)        !parameter used in CNAllocation
  real(r8), allocatable :: aleaff(:)       !parameter used in CNAllocation
  real(r8), allocatable :: arootf(:)       !parameter used in CNAllocation
  real(r8), allocatable :: astemf(:)       !parameter used in CNAllocation
  real(r8), allocatable :: arooti(:)       !parameter used in CNAllocation
  real(r8), allocatable :: fleafi(:)       !parameter used in CNAllocation
  real(r8), allocatable :: allconsl(:)     !parameter used in CNAllocation
  real(r8), allocatable :: allconss(:)     !parameter used in CNAllocation
  real(r8), allocatable :: ztopmx(:)       !parameter used in VegStructUpdate
  real(r8), allocatable :: laimx(:)        !parameter used in VegStructUpdate
  real(r8), allocatable :: gddmin(:)       !parameter used in Phenology
  real(r8), allocatable :: hybgdd(:)       !parameter used in Phenology
  real(r8), allocatable :: lfemerg(:)      !parameter used in Phenology
  real(r8), allocatable :: grnfill(:)      !parameter used in Phenology
  integer , allocatable :: mxmat(:)        !parameter used in Phenology
  integer , allocatable :: mnNHplantdate(:)!minimum planting date for NorthHemisphere (YYYYMMDD)
  integer , allocatable :: mxNHplantdate(:)!maximum planting date for NorthHemisphere (YYYYMMDD)
  integer , allocatable :: mnSHplantdate(:)!minimum planting date for SouthHemisphere (YYYYMMDD)
  integer , allocatable :: mxSHplantdate(:)!maximum planting date for SouthHemisphere (YYYYMMDD)
  real(r8), allocatable :: planttemp(:)    !planting temperature used in Phenology (K)
  real(r8), allocatable :: minplanttemp(:) !mininum planting temperature used in Phenology (K)
  real(r8), allocatable :: senestemp(:)    !senescence temperature for perennial crops used in Phenology (K)
  real(r8), allocatable :: min_days_senes(:)   !minimum leaf age to allow for leaf senescence
  real(r8), allocatable :: froot_leaf(:)   !allocation parameter: new fine root C per new leaf C (gC/gC) 
  real(r8), allocatable :: stem_leaf(:)    !allocation parameter: new stem c per new leaf C (gC/gC)
  real(r8), allocatable :: croot_stem(:)   !allocation parameter: new coarse root C per new stem C (gC/gC)
  real(r8), allocatable :: flivewd(:)      !allocation parameter: fraction of new wood that is live (phloem and ray parenchyma) (no units)
  real(r8), allocatable :: fcur(:)         !allocation parameter: fraction of allocation that goes to currently displayed growth, remainder to storage
  real(r8), allocatable :: lf_flab(:)      !leaf litter labile fraction
  real(r8), allocatable :: lf_fcel(:)      !leaf litter cellulose fraction
  real(r8), allocatable :: lf_flig(:)      !leaf litter lignin fraction
  real(r8), allocatable :: fr_flab(:)      !fine root litter labile fraction
  real(r8), allocatable :: fr_fcel(:)      !fine root litter cellulose fraction
  real(r8), allocatable :: fr_flig(:)      !fine root litter lignin fraction
  real(r8), allocatable :: leaf_long(:)    !leaf longevity (yrs)
  real(r8), allocatable :: froot_long(:)   !fine root longevity(yrs)
  real(r8), allocatable :: evergreen(:)    !binary flag for evergreen leaf habit (0 or 1)
  real(r8), allocatable :: stress_decid(:) !binary flag for stress-deciduous leaf habit (0 or 1)
  real(r8), allocatable :: season_decid(:) !binary flag for seasonal-deciduous leaf habit (0 or 1)
  real(r8), allocatable :: pconv(:)        !proportion of deadstem to conversion flux
  real(r8), allocatable :: pprod10(:)      !proportion of deadstem to 10-yr product pool
  real(r8), allocatable :: pprod100(:)     !proportion of deadstem to 100-yr product pool
  real(r8), allocatable :: pprodharv10(:)  !harvest mortality proportion of deadstem to 10-yr pool
  ! pft paraemeters for fire code
  real(r8), allocatable :: cc_leaf(:)
  real(r8), allocatable :: cc_lstem(:)
  real(r8), allocatable :: cc_dstem(:)
  real(r8), allocatable :: cc_other(:)
  real(r8), allocatable :: fm_leaf(:)
  real(r8), allocatable :: fm_lstem(:)
  real(r8), allocatable :: fm_dstem(:)
  real(r8), allocatable :: fm_other(:)
  real(r8), allocatable :: fm_root(:)
  real(r8), allocatable :: fm_lroot(:)
  real(r8), allocatable :: fm_droot(:)
  real(r8), allocatable :: fsr_pft(:)
  real(r8), allocatable :: fd_pft(:)
  ! pft parameters for crop code
  real(r8), allocatable :: fertnitro(:)    !fertilizer
  real(r8), allocatable :: fleafcn(:)      !C:N during grain fill; leaf
  real(r8), allocatable :: ffrootcn(:)     !C:N during grain fill; fine root
  real(r8), allocatable :: fstemcn(:)      !C:N during grain fill; stem
  real(r8), allocatable :: presharv(:)     !porportion of residue harvested
  real(r8), allocatable :: convfact(:)     !conversion factor to bu/acre
  real(r8), allocatable :: fyield(:)       !fraction of grain that is actually harvested
  real(r8), allocatable :: root_dmx(:)     !maximum root depth

  integer, parameter :: pftname_len = 40    ! max length of pftname       
  character(len=:), allocatable :: pftname(:) !PFT description

  real(r8), parameter :: reinickerp = 1.6_r8 !parameter in allometric equation
  real(r8), parameter :: dwood  = 2.5e5_r8   !cn wood density (gC/m3); lpj:2.0e5
  real(r8), parameter :: allom1 = 100.0_r8   !parameters in
  real(r8), parameter :: allom2 =  40.0_r8   !...allometric
  real(r8), parameter :: allom3 =   0.5_r8   !...equations
  real(r8), parameter :: allom1s = 250.0_r8  !modified for shrubs by
  real(r8), parameter :: allom2s =   8.0_r8  !X.D.Z

  ! Q. Zhu add pft dependent parameters for phosphorus for nutrient competition
  real(r8), allocatable :: VMAX_PLANT_NH4(:)   ! VMAX for plant NH4 uptake
  real(r8), allocatable :: VMAX_PLANT_NO3(:)   ! VMAX for plant NO3 uptake
  real(r8), allocatable :: VMAX_PLANT_P(:)     ! VMAX for plant P uptake
  real(r8), allocatable :: VMAX_MINSURF_P_vr(:,:)! VMAX for P adsorption -> move to soilorder_varcon
  real(r8), allocatable :: KM_PLANT_NH4(:)     ! KM for plant NH4 uptake
  real(r8), allocatable :: KM_PLANT_NO3(:)     ! KM for plant NO3 uptake
  real(r8), allocatable :: KM_PLANT_P(:)       ! KM for plant P uptake
  real(r8), allocatable :: KM_MINSURF_P_vr(:,:)! KM for P adsorption -> move to soilorder_varcon
  real(r8)              :: KM_DECOMP_NH4       ! KM for microbial decomposer NH4 uptake
  real(r8)              :: KM_DECOMP_NO3       ! KM for microbial decomposer NO3 uptake
  real(r8)              :: KM_DECOMP_P         ! KM for microbial decomposer P uptake
  real(r8)              :: KM_NIT              ! KM for nitrifier NH4 uptake
  real(r8)              :: KM_DEN              ! KM for denitrifier NO3 uptake
  real(r8), allocatable :: decompmicc_patch_vr(:,:) ! microbial decomposer biomass gC/m3
  real(r8), allocatable :: alpha_nfix(:)            ! fraction of fixed N goes directly to plant
  real(r8), allocatable :: alpha_ptase(:)           ! fraction of phosphatase produced P goes directly to plant
  real(r8), allocatable :: ccost_nfix(:)            ! plant C cost per unit N produced by N2 fixation
  real(r8), allocatable :: pcost_nfix(:)            ! plant P cost per unit N produced by N2 fixation
  real(r8), allocatable :: ccost_ptase(:)           ! plant C cost per unit P produced by phosphatase
  real(r8), allocatable :: ncost_ptase(:)           ! plant N cost per unit P produced by phosphatase
  real(r8), allocatable :: VMAX_NFIX(:)        ! VMAX of symbiotic N2 fixation
  real(r8), allocatable :: KM_NFIX(:)          ! KM of symbiotic N2 fixation
  real(r8), allocatable :: VMAX_PTASE(:)       ! VMAX of biochemical P production
  real(r8)              :: KM_PTASE            ! KM of biochemical P production
  real(r8)              :: lamda_ptase         ! critical value that incur biochemical production
  real(r8), allocatable :: i_vc(:)             ! intercept of photosynthesis vcmax ~ leaf N content regression model
  real(r8), allocatable :: s_vc(:)             ! slope of photosynthesis vcmax ~ leaf N content regression model
  real(r8), allocatable :: nsc_rtime(:)        ! non-structural carbon residence time
  real(r8), allocatable :: pinit_beta1(:)      ! shaping parameter for P initialization
  real(r8), allocatable :: pinit_beta2(:)      ! shaping parameter for P initialization
  ! new stoichiometry
  real(r8), allocatable :: leafcn_obs(:)       !leaf C:N [gC/gN]
  real(r8), allocatable :: frootcn_obs(:)      !fine root C:N (gC/gN)
  real(r8), allocatable :: livewdcn_obs(:)     !live wood (phloem and ray parenchyma) C:N (gC/gN)
  real(r8), allocatable :: deadwdcn_obs(:)     !dead wood (xylem and heartwood) C:N (gC/gN)
  real(r8), allocatable :: leafcp_obs(:)       !leaf C:P [gC/gP]
  real(r8), allocatable :: frootcp_obs(:)      !fine root C:P (gC/gP)
  real(r8), allocatable :: livewdcp_obs(:)     !live wood (phloem and ray parenchyma) C:P (gC/gP)
  real(r8), allocatable :: deadwdcp_obs(:)     !dead wood (xylem and heartwood) C:P (gC/gP)
  real(r8), allocatable :: leafcn_obs_flex(:,:)       !upper and lower range of leaf C:N [gC/gN]
  real(r8), allocatable :: frootcn_obs_flex(:,:)      !upper and lower range of fine root C:N (gC/gN)
  real(r8), allocatable :: livewdcn_obs_flex(:,:)     !upper and lower range of live wood (phloem and ray parenchyma) C:N (gC/gN)
  real(r8), allocatable :: deadwdcn_obs_flex(:,:)     !upper and lower range of dead wood (xylem and heartwood) C:N (gC/gN)
  real(r8), allocatable :: leafcp_obs_flex(:,:)       !upper and lower range of leaf C:P [gC/gP]
  real(r8), allocatable :: frootcp_obs_flex(:,:)      !upper and lower range of fine root C:P (gC/gP)
  real(r8), allocatable :: livewdcp_obs_flex(:,:)     !upper and lower range of live wood (phloem and ray parenchyma) C:P (gC/gP)
  real(r8), allocatable :: deadwdcp_obs_flex(:,:)     !upper and lower range of dead wood (xylem and heartwood) C:P (gC/gP)
  ! Photosynthesis parameters
  real(r8), allocatable :: fnr(:)              !fraction of nitrogen in RuBisCO
  real(r8), allocatable :: act25(:)
  real(r8), allocatable :: kcha(:)             !Activation energy for kc
  real(r8), allocatable :: koha(:)             !Activation energy for ko
  real(r8), allocatable :: cpha(:)             !Activation energy for cp
  real(r8), allocatable :: vcmaxha(:)          !Activation energy for vcmax
  real(r8), allocatable :: jmaxha(:)           !Activation energy for jmax
  real(r8), allocatable :: tpuha(:)            !Activation energy for tpu
  real(r8), allocatable :: lmrha(:)            !Acitivation energy for lmr
  real(r8), allocatable :: vcmaxhd(:)          !Deactivation energy for vcmax
  real(r8), allocatable :: jmaxhd(:)           !Deactivation energy for jmax
  real(r8), allocatable :: tpuhd(:)            !Deactivation energy for tpu
  real(r8), allocatable :: lmrhd(:)            !Deacitivation energy for lmr
  real(r8), allocatable :: lmrse(:)            !SE for lmr
  real(r8), allocatable :: qe(:)               !Quantum efficiency
  real(r8), allocatable :: theta_cj(:)         !
  real(r8), allocatable :: bbbopt(:)           !Ball-Berry stomatal conductance intercept
  real(r8), allocatable :: mbbopt(:)           !Ball-Berry stomatal conductance slope
  real(r8), allocatable :: nstor(:)            !Nitrogen storage pool timescale
  real(r8), allocatable :: br_xr(:)            !Base rate for excess respiration
  real(r8)              :: tc_stress           !Critial temperature for moisture stress
  real(r8), allocatable :: vcmax_np1(:)        !vcmax~np relationship coefficient
  real(r8), allocatable :: vcmax_np2(:)        !vcmax~np relationship coefficient
  real(r8), allocatable :: vcmax_np3(:)        !vcmax~np relationship coefficient
  real(r8), allocatable :: vcmax_np4(:)        !vcmax~np relationship coefficient
  real(r8)              :: jmax_np1            !jmax~np relationship coefficient
  real(r8)              :: jmax_np2            !jmax~np relationship coefficient
  real(r8)              :: jmax_np3            !jmax~np relationship coefficient
  real(r8)              :: laimax
  ! Hydrology
  real(r8)              :: rsub_top_globalmax
  ! Soil erosion ground cover
  real(r8), allocatable :: gcpsi(:)            !bare ground LAI-decay parameter
  real(r8), allocatable :: pftcc(:)            !plant cover reduction factor for transport capacity

  !$acc declare create(rsub_top_globalmax, gcpsi, pftcc)

  !$acc declare create(mergetoelmpft         (:))
  !$acc declare create(is_pft_known_to_model (:))
  !$acc declare create(graincn(:)      )
  !$acc declare create(graincp(:)      )
  !$acc declare create(mxtmp(:)        )
  !$acc declare create(baset(:)        )
  !$acc declare create(declfact(:)     )
  !$acc declare create(bfact(:)        )
  !$acc declare create(aleaff(:)       )
  !$acc declare create(arootf(:)       )
  !$acc declare create(astemf(:)       )
  !$acc declare create(arooti(:)       )
  !$acc declare create(fleafi(:)       )
  !$acc declare create(allconsl(:)     )
  !$acc declare create(allconss(:)     )
  !$acc declare create(ztopmx(:)       )
  !$acc declare create(laimx(:)        )
  !$acc declare create(gddmin(:)       )
  !$acc declare create(hybgdd(:)       )
  !$acc declare create(lfemerg(:)      )
  !$acc declare create(grnfill(:)      )
  !$acc declare create(mxmat(:)        )
  !$acc declare create(mnNHplantdate(:))
  !$acc declare create(mxNHplantdate(:))
  !$acc declare create(mnSHplantdate(:))
  !$acc declare create(mxSHplantdate(:))
  !$acc declare create(planttemp(:)    )
  !$acc declare create(minplanttemp(:) )
  !$acc declare create(froot_leaf(:)   )
  !$acc declare create(stem_leaf(:)    )
  !$acc declare create(croot_stem(:)   )
  !$acc declare create(flivewd(:)      )
  !$acc declare create(fcur(:)         )
  !$acc declare create(lf_flab(:)      )
  !$acc declare create(lf_fcel(:)      )
  !$acc declare create(lf_flig(:)      )
  !$acc declare create(fr_flab(:)      )
  !$acc declare create(fr_fcel(:)      )
  !$acc declare create(fr_flig(:)      )
  !$acc declare create(leaf_long(:)    )
  !$acc declare create(froot_long(:)   )
  !$acc declare create(evergreen(:)    )
  !$acc declare create(stress_decid(:) )
  !$acc declare create(season_decid(:) )
  !$acc declare create(pconv(:)        )
  !$acc declare create(pprod10(:)      )
  !$acc declare create(pprod100(:)     )
  !$acc declare create(pprodharv10(:)  )
  !$acc declare create(cc_leaf(:) )
  !$acc declare create(cc_lstem(:))
  !$acc declare create(cc_dstem(:))
  !$acc declare create(cc_other(:))
  !$acc declare create(fm_leaf(:) )
  !$acc declare create(fm_lstem(:))
  !$acc declare create(fm_dstem(:))
  !$acc declare create(fm_other(:))
  !$acc declare create(fm_root(:) )
  !$acc declare create(fm_lroot(:))
  !$acc declare create(fm_droot(:))
  !$acc declare create(fsr_pft(:) )
  !$acc declare create(fd_pft(:)  )
  !$acc declare create(fertnitro(:))
  !$acc declare create(fleafcn(:)  )
  !$acc declare create(ffrootcn(:) )
  !$acc declare create(fstemcn(:)  )
  !$acc declare create(presharv(:) )
  !$acc declare create(convfact(:) )
  !$acc declare create(fyield(:)   )
  !$acc declare create(root_dmx(:) )
  !$acc declare copyin(reinickerp)
  !$acc declare copyin(dwood     )
  !$acc declare copyin(allom1    )
  !$acc declare copyin(allom2    )
  !$acc declare copyin(allom3    )
  !$acc declare copyin(allom1s   )
  !$acc declare copyin(allom2s   )
  !$acc declare create(VMAX_PLANT_NH4(:)   )
  !$acc declare create(VMAX_PLANT_NO3(:)   )
  !$acc declare create(VMAX_PLANT_P(:)     )
  !$acc declare create(VMAX_MINSURF_P_vr(:,:) )
  !$acc declare create(KM_PLANT_NH4(:)     )
  !$acc declare create(KM_PLANT_NO3(:)     )
  !$acc declare create(KM_PLANT_P(:)       )
  !$acc declare create(KM_MINSURF_P_vr(:,:))
  !$acc declare create(KM_DECOMP_NH4       )
  !$acc declare create(KM_DECOMP_NO3       )
  !$acc declare create(KM_DECOMP_P         )
  !$acc declare create(KM_NIT              )
  !$acc declare create(KM_DEN              )
  !$acc declare create(decompmicc_patch_vr(:,:))
  !$acc declare create(alpha_nfix(:)           )
  !$acc declare create(alpha_ptase(:)          )
  !$acc declare create(ccost_nfix(:)           )
  !$acc declare create(pcost_nfix(:)           )
  !$acc declare create(ccost_ptase(:)          )
  !$acc declare create(ncost_ptase(:)          )
  !$acc declare create(VMAX_NFIX(:)        )
  !$acc declare create(KM_NFIX(:)          )
  !$acc declare create(VMAX_PTASE(:)       )
  !$acc declare create(KM_PTASE            )
  !$acc declare create(lamda_ptase         )
  !$acc declare create(i_vc(:)             )
  !$acc declare create(s_vc(:)             )
  !$acc declare create(leafcn_obs(:)         )
  !$acc declare create(frootcn_obs(:)        )
  !$acc declare create(livewdcn_obs(:)       )
  !$acc declare create(deadwdcn_obs(:)       )
  !$acc declare create(leafcp_obs(:)         )
  !$acc declare create(frootcp_obs(:)        )
  !$acc declare create(livewdcp_obs(:)       )
  !$acc declare create(deadwdcp_obs(:)       )
  !$acc declare create(leafcn_obs_flex(:,:)  )
  !$acc declare create(frootcn_obs_flex(:,:) )
  !$acc declare create(livewdcn_obs_flex(:,:))
  !$acc declare create(deadwdcn_obs_flex(:,:))
  !$acc declare create(leafcp_obs_flex(:,:)  )
  !$acc declare create(frootcp_obs_flex(:,:) )
  !$acc declare create(livewdcp_obs_flex(:,:))
  !$acc declare create(deadwdcp_obs_flex(:,:))
  !$acc declare create(fnr(:)      )
  !$acc declare create(act25(:)    )
  !$acc declare create(kcha(:)     )
  !$acc declare create(koha(:)     )
  !$acc declare create(cpha(:)     )
  !$acc declare create(vcmaxha(:)  )
  !$acc declare create(jmaxha(:)   )
  !$acc declare create(tpuha(:)    )
  !$acc declare create(lmrha(:)    )
  !$acc declare create(vcmaxhd(:)  )
  !$acc declare create(jmaxhd(:)   )
  !$acc declare create(tpuhd(:)    )
  !$acc declare create(lmrhd(:)    )
  !$acc declare create(lmrse(:)    )
  !$acc declare create(qe(:)       )
  !$acc declare create(theta_cj(:) )
  !$acc declare create(bbbopt(:)   )
  !$acc declare create(mbbopt(:)   )
  !$acc declare create(nstor(:)    )
  !$acc declare create(br_xr(:)    )
  !$acc declare create(tc_stress   )
  !$acc declare create(vcmax_np1(:))
  !$acc declare create(vcmax_np2(:))
  !$acc declare create(vcmax_np3(:))
  !$acc declare create(vcmax_np4(:))
  !$acc declare create(jmax_np1    )
  !$acc declare create(jmax_np2    )
  !$acc declare create(jmax_np3    )
  !$acc declare create(laimax      )

  !
  ! !PUBLIC MEMBER FUNCTIONS:
  public :: pftconrd ! Read and initialize vegetation (PFT) constants
  !
  ! !REVISION HISTORY:
  ! Created by Sam Levis (put into module form by Mariana Vertenstein)
  ! 10/21/03, Peter Thornton: Added new variables for CN code
  ! 06/24/09, Erik Kluzek: Add indices for all pft types, and add expected_pftnames array and comparision
  ! 09/17/10, David Lawrence: Modified code to read in netCDF pft physiology file
  !-----------------------------------------------------------------------

contains

  !-----------------------------------------------------------------------
  subroutine pftconrd
    !
    ! !DESCRIPTION:
    ! Read and initialize vegetation (PFT) constants
    !
    ! !USES:
    !#py use fileutils ,  only : getfil
    !#py use ncdio_pio ,  only : ncd_io, ncd_pio_closefile, ncd_pio_openfile, file_desc_t, &
    !#py                        ncd_inqdid, ncd_inqdlen
    use elm_varctl,  only : paramfile, use_fates
    use elm_varctl,  only : use_crop, use_dynroot
    use elm_varcon,  only : tfrz
    !#py use spmdMod   ,  only : masterproc

    !
    ! !ARGUMENTS:
    implicit none
    !
    ! !REVISION HISTORY:
    ! Created by Gordon Bonan
    ! F. Li and S. Levis (11/06/12)
    !
    ! !LOCAL VARIABLES:
    character(len=256) :: locfn ! local file name
    integer :: i,n              ! loop indices
    integer :: ier              ! error code
    !#py type(file_desc_t) :: ncid   ! pio netCDF file id
    integer :: dimid            ! netCDF dimension id
    integer :: npft             ! number of pfts on pft-physiology file
    logical :: readv            ! read variable in or not
    character(len=32) :: subname = 'pftconrd'              ! subroutine name
    !
    ! Expected PFT names: The names expected on the paramfile file and the order they are expected to be in.
    ! NOTE: similar types are assumed to be together, first trees (ending with broadleaf_deciduous_boreal_tree
    !       then shrubs, ending with broadleaf_deciduous_boreal_shrub, then grasses starting with c3_arctic_grass
    !       and finally crops, ending with soybean
    ! DO NOT CHANGE THE ORDER -- WITHOUT MODIFYING OTHER PARTS OF THE CODE WHERE THE ORDER MATTERS!
    !
    character(len=pftname_len) :: expected_pftnames(0:mxpft)
    !-----------------------------------------------------------------------

    !expected_pftnames( 0) = 'not_vegetated                      '
    !expected_pftnames( 1) = 'needleleaf_evergreen_temperate_tree'
    !expected_pftnames( 2) = 'needleleaf_evergreen_boreal_tree   '
    !expected_pftnames( 3) = 'needleleaf_deciduous_boreal_tree   '
    !expected_pftnames( 4) = 'broadleaf_evergreen_tropical_tree  '
    !expected_pftnames( 5) = 'broadleaf_evergreen_temperate_tree '
    !expected_pftnames( 6) = 'broadleaf_deciduous_tropical_tree  '
    !expected_pftnames( 7) = 'broadleaf_deciduous_temperate_tree '
    !expected_pftnames( 8) = 'broadleaf_deciduous_boreal_tree    '
    !expected_pftnames( 9) = 'broadleaf_evergreen_shrub          '
    !expected_pftnames(10) = 'broadleaf_deciduous_temperate_shrub'
    !expected_pftnames(11) = 'broadleaf_deciduous_boreal_shrub   '
    !expected_pftnames(12) = 'c3_arctic_grass                    '
    !expected_pftnames(13) = 'c3_non-arctic_grass                '
    !expected_pftnames(14) = 'c4_grass                           '
    !expected_pftnames(15) = 'c3_crop                            '
    !expected_pftnames(16) = 'c3_irrigated                       '
    !expected_pftnames(17) = 'corn                               '
    !expected_pftnames(18) = 'irrigated_corn                     '
    !expected_pftnames(19) = 'spring_temperate_cereal            '
    !expected_pftnames(20) = 'irrigated_spring_temperate_cereal  '
    !expected_pftnames(21) = 'winter_temperate_cereal            '
    !expected_pftnames(22) = 'irrigated_winter_temperate_cereal  '
    !expected_pftnames(23) = 'soybean                            '
    !expected_pftnames(24) = 'irrigated_soybean                  '
    !expected_pftnames(25) = 'cassava                            '
    !expected_pftnames(26) = 'irrigated_cassava                  '
    !expected_pftnames(27) = 'cotton                             '
    !expected_pftnames(28) = 'irrigated_cotton                   '
    !expected_pftnames(29) = 'foddergrass                        '
    !expected_pftnames(30) = 'irrigated_foddergrass              '
    !expected_pftnames(31) = 'oilpalm                            '
    !expected_pftnames(32) = 'irrigated_oilpalm                  '
    !expected_pftnames(33) = 'other_grains                       '
    !expected_pftnames(34) = 'irrigated_other_grains             '
    !expected_pftnames(35) = 'rapeseed                           '
    !expected_pftnames(36) = 'irrigated_rapeseed                 '
    !expected_pftnames(37) = 'rice                               '
    !expected_pftnames(38) = 'irrigated_rice                     '
    !expected_pftnames(39) = 'root_tubers                        '
    !expected_pftnames(40) = 'irrigated_root_tubers              '
    !expected_pftnames(41) = 'sugarcane                          '
    !expected_pftnames(42) = 'irrigated_sugarcane                '
    !expected_pftnames(43) = 'miscanthus                         '
    !expected_pftnames(44) = 'irrigated_miscanthus               '
    !expected_pftnames(45) = 'switchgrass                        '
    !expected_pftnames(46) = 'irrigated_switchgrass              '
    !expected_pftnames(47) = 'poplar                             '
    !expected_pftnames(48) = 'irrigated_poplar                   '
    !expected_pftnames(49) = 'willow                             '
    !expected_pftnames(50) = 'irrigated_willow                   '

    allocate( dleaf         (0:mxpft) )       
    allocate( c3psn         (0:mxpft) )       
    allocate( xl            (0:mxpft) )          
    allocate( rhol          (0:mxpft,numrad) ) 
    allocate( rhos          (0:mxpft,numrad) ) 
    allocate( taul          (0:mxpft,numrad) ) 
    allocate( taus          (0:mxpft,numrad) ) 
    allocate( z0mr          (0:mxpft) )        
    allocate( displar       (0:mxpft) )     
    allocate( roota_par     (0:mxpft) )   
    allocate( rootb_par     (0:mxpft) )   
    allocate( crop          (0:mxpft) )        
    allocate( percrop       (0:mxpft) )
    allocate( irrigated     (0:mxpft) )   
    allocate( smpso         (0:mxpft) )       
    allocate( smpsc         (0:mxpft) )       
    allocate( fnitr         (0:mxpft) )       
    allocate( slatop        (0:mxpft) )      
    allocate( dsladlai      (0:mxpft) )    
    allocate( leafcn        (0:mxpft) )
    allocate( flnr          (0:mxpft) )        
    allocate( woody         (0:mxpft) )       
    allocate( lflitcn       (0:mxpft) )      
    allocate( frootcn       (0:mxpft) )      
    allocate( livewdcn      (0:mxpft) )     
    allocate( deadwdcn      (0:mxpft) )     

    ! add phosphorus 
    allocate( leafcp        (0:mxpft) )      
    allocate( lflitcp       (0:mxpft) )      
    allocate( frootcp       (0:mxpft) )      
    allocate( livewdcp      (0:mxpft) )     
    allocate( deadwdcp      (0:mxpft) )     

    allocate( grperc        (0:mxpft) )       
    allocate( grpnow        (0:mxpft) )       
    allocate( rootprof_beta (0:mxpft) )

    allocate( mergetoelmpft (0:mxpft) )
    allocate( is_pft_known_to_model  (0:mxpft) )

    allocate( graincn       (0:mxpft) )
    allocate( graincp       (0:mxpft) )
    allocate( mxtmp         (0:mxpft) )
    allocate( baset         (0:mxpft) )
    allocate( declfact      (0:mxpft) )
    allocate( bfact         (0:mxpft) )
    allocate( aleaff        (0:mxpft) )
    allocate( arootf        (0:mxpft) )
    allocate( astemf        (0:mxpft) )
    allocate( arooti        (0:mxpft) )
    allocate( fleafi        (0:mxpft) )
    allocate( allconsl      (0:mxpft) )
    allocate( allconss      (0:mxpft) )
    allocate( ztopmx        (0:mxpft) )
    allocate( laimx         (0:mxpft) )
    allocate( gddmin        (0:mxpft) )
    allocate( hybgdd        (0:mxpft) )
    allocate( lfemerg       (0:mxpft) )
    allocate( grnfill       (0:mxpft) )
    allocate( mxmat         (0:mxpft) )
    allocate( mnNHplantdate (0:mxpft) )
    allocate( mxNHplantdate (0:mxpft) )
    allocate( mnSHplantdate (0:mxpft) )
    allocate( mxSHplantdate (0:mxpft) )
    allocate( planttemp     (0:mxpft) )    
    allocate( minplanttemp  (0:mxpft) ) 
    allocate( senestemp     (0:mxpft) )
    allocate( min_days_senes (0:mxpft) )
    allocate( froot_leaf    (0:mxpft) )   
    allocate( stem_leaf     (0:mxpft) )    
    allocate( croot_stem    (0:mxpft) )   
    allocate( flivewd       (0:mxpft) )      
    allocate( fcur          (0:mxpft) )         
    allocate( lf_flab       (0:mxpft) )      
    allocate( lf_fcel       (0:mxpft) )      
    allocate( lf_flig       (0:mxpft) )      
    allocate( fr_flab       (0:mxpft) )      
    allocate( fr_fcel       (0:mxpft) )      
    allocate( fr_flig       (0:mxpft) )      
    allocate( leaf_long     (0:mxpft) )   
    allocate( froot_long    (0:mxpft) )
    allocate( evergreen     (0:mxpft) )
    allocate( stress_decid  (0:mxpft) )
    allocate( season_decid  (0:mxpft) )
    allocate( pconv         (0:mxpft) )
    allocate( pprod10       (0:mxpft) )
    allocate( pprod100      (0:mxpft) )
    allocate( pprodharv10   (0:mxpft) )
    allocate( cc_leaf       (0:mxpft) )
    allocate( cc_lstem      (0:mxpft) )
    allocate( cc_dstem      (0:mxpft) )
    allocate( cc_other      (0:mxpft) )
    allocate( fm_leaf       (0:mxpft) )
    allocate( fm_lstem      (0:mxpft) )
    allocate( fm_dstem      (0:mxpft) )
    allocate( fm_other      (0:mxpft) )
    allocate( fm_root       (0:mxpft) )
    allocate( fm_lroot      (0:mxpft) )
    allocate( fm_droot      (0:mxpft) )
    allocate( fsr_pft       (0:mxpft) )
    allocate( fd_pft        (0:mxpft) )
    allocate( fertnitro     (0:mxpft) )
    allocate( fleafcn       (0:mxpft) )
    allocate( ffrootcn      (0:mxpft) )
    allocate( fstemcn       (0:mxpft) )
    allocate( presharv      (0:mxpft) )
    allocate( convfact      (0:mxpft) )
    allocate( fyield        (0:mxpft) )
    allocate( root_dmx      (0:mxpft) )

    if (use_crop) then
       allocate(character(pftname_len) :: pftname(0:mxpft))
    else
       allocate(character(pftname_len) :: pftname(0:mxpft_nc))
    end if

    allocate( VMAX_PLANT_NH4(0:mxpft) )
    allocate( VMAX_PLANT_NO3(0:mxpft) )
    allocate( VMAX_PLANT_P(0:mxpft) )
    allocate( VMAX_MINSURF_P_vr(1:nlevdecomp_full,0:nsoilorder))
    allocate( KM_PLANT_NH4(0:mxpft) )
    allocate( KM_PLANT_NO3(0:mxpft) )
    allocate( KM_PLANT_P(0:mxpft) )
    allocate( KM_MINSURF_P_vr(1:nlevdecomp_full,0:nsoilorder))
    allocate( decompmicc_patch_vr (1:nlevdecomp_full,0:mxpft))
    allocate( VMAX_PTASE(0:mxpft))
    allocate( i_vc               (0:mxpft) ) 
    allocate( s_vc               (0:mxpft) ) 
    allocate( nsc_rtime          (0:mxpft) )
    allocate( pinit_beta1        (0:nsoilorder))
    allocate( pinit_beta2        (0:nsoilorder))
    allocate( alpha_nfix         (0:mxpft) )
    allocate( alpha_ptase        (0:mxpft) )
    allocate( ccost_nfix         (0:mxpft) )
    allocate( pcost_nfix         (0:mxpft) )
    allocate( ccost_ptase        (0:mxpft) )
    allocate( ncost_ptase        (0:mxpft) )
    allocate( VMAX_NFIX          (0:mxpft) )
    allocate( KM_NFIX            (0:mxpft) )
    ! new stoichiometry
    allocate( leafcn_obs         (0:mxpft) )
    allocate( frootcn_obs        (0:mxpft) )
    allocate( livewdcn_obs       (0:mxpft) )
    allocate( deadwdcn_obs       (0:mxpft) )
    allocate( leafcp_obs         (0:mxpft) )
    allocate( frootcp_obs        (0:mxpft) )
    allocate( livewdcp_obs       (0:mxpft) )
    allocate( deadwdcp_obs       (0:mxpft) )
    allocate( leafcn_obs_flex         (0:mxpft,1:2) )
    allocate( frootcn_obs_flex        (0:mxpft,1:2) )
    allocate( livewdcn_obs_flex       (0:mxpft,1:2) )
    allocate( deadwdcn_obs_flex       (0:mxpft,1:2) )
    allocate( leafcp_obs_flex         (0:mxpft,1:2) )
    allocate( frootcp_obs_flex        (0:mxpft,1:2) )
    allocate( livewdcp_obs_flex       (0:mxpft,1:2) )
    allocate( deadwdcp_obs_flex       (0:mxpft,1:2) )
    allocate( vcmax_np1          (0:mxpft) )
    allocate( vcmax_np2          (0:mxpft) )
    allocate( vcmax_np3          (0:mxpft) )
    allocate( vcmax_np4          (0:mxpft) )
    ! Photosynthesis
    allocate( fnr                (0:mxpft) )
    allocate( act25              (0:mxpft) )
    allocate( kcha               (0:mxpft) )
    allocate( koha               (0:mxpft) )
    allocate( cpha               (0:mxpft) )
    allocate( vcmaxha            (0:mxpft) )
    allocate( jmaxha             (0:mxpft) )
    allocate( tpuha              (0:mxpft) )
    allocate( lmrha              (0:mxpft) )
    allocate( vcmaxhd            (0:mxpft) )
    allocate( jmaxhd             (0:mxpft) )
    allocate( tpuhd              (0:mxpft) )
    allocate( lmrhd              (0:mxpft) )
    allocate( lmrse              (0:mxpft) )
    allocate( qe                 (0:mxpft) )
    allocate( theta_cj           (0:mxpft) )
    allocate( bbbopt             (0:mxpft) )
    allocate( mbbopt             (0:mxpft) )
    allocate( nstor              (0:mxpft) )
    allocate( br_xr              (0:mxpft) )
    ! Ground cover for soil erosion
    allocate( gcpsi              (0:mxpft) )
    allocate( pftcc              (0:mxpft) )

    ! Set specific vegetation type values

    if (masterproc) then
       !#py write(iulog,*) 'Successfully read PFT physiological data'
       !#py write(iulog,*)
    end if

  end subroutine pftconrd

  !-----------------------------------------------------------------------
  subroutine set_is_pft_known_to_model()
    !
    ! !DESCRIPTION:
    ! Set is_pft_known_to_model based on mergetoelmpft
    !
    ! !USES:
    !
    ! !LOCAL VARIABLES:
    integer :: m, merge_type

    character(len=*), parameter :: subname = 'set_is_pft_known_to_model'
    !-----------------------------------------------------------------------

    is_pft_known_to_model(:) = .false.

    ! NOTE(wjs, 2015-10-04) Currently, type 0 has mergetoelmpft = _FillValue in the file,
    ! so we can't handle it in the general loop below. But CLM always uses type 0, so
    ! handle it specially here.
    is_pft_known_to_model(0) = .true.

    ! NOTE(wjs, 2015-10-04) Currently, mergetoelmpft is only used for crop types.
    ! However, we handle it more generally here (treating ALL pft types), in case its use
    ! is ever extended to work with non-crop types as well.
    do m = 1, mxpft
       merge_type                        = mergetoelmpft(m)
       is_pft_known_to_model(merge_type) = .true.
    end do

  end subroutine set_is_pft_known_to_model

  !-----------------------------------------------------------------------
  subroutine set_num_cfts_known_to_model()
    !
    ! !DESCRIPTION:
    ! Set the module-level variable, num_cfts_known_to_model
    !
    ! !USES:
    !
    ! !LOCAL VARIABLES:
    integer :: m

    character(len=*), parameter :: subname = 'set_num_cfts_known_to_model'
    !-----------------------------------------------------------------------

    num_cfts_known_to_model = 0
    do m = cft_lb, cft_ub
       if (is_pft_known_to_model(m)) then
          num_cfts_known_to_model = num_cfts_known_to_model + 1
       end if
    end do

  end subroutine set_num_cfts_known_to_model

end module pftvarcon
