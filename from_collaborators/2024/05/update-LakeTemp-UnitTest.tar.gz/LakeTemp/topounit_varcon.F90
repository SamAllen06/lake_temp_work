module topounit_varcon
#include "unittest_defs.h"

  !-----------------------------------------------------------------------
  ! !DESCRIPTION:
  ! Module containing topounit indices and associated variables and routines.
  !
  ! !USES:
!#include "shr_assert.h"
  !#py use ncdio_pio       , only : file_desc_t, var_desc_t, ncd_pio_openfile, ncd_pio_closefile
  !#py use ncdio_pio       , only : ncd_io, check_var, ncd_inqfdims, check_dim, ncd_inqdid, ncd_inqdlen
  use elm_varctl      , only: fsurdat, iulog
  use shr_kind_mod    , only : r8 => shr_kind_r8
  !#py use shr_log_mod     , only : errMsg => shr_log_errMsg
  !use abortutils      , only : endrun
  use elm_varcon      , only : grlnd
  !#py use pio
  !#py use spmdMod
  !
  !
  ! !PUBLIC TYPES:
  implicit none
  save
  private
  
  !------------------------------------------------------------------
  ! Initialize topounit type constants
  !------------------------------------------------------------------
  
  integer, public :: max_topounits  = 1 ! maximum number of topounits per gridcell
  logical, public :: has_topounit                ! true => topounit dimension is on dataset
  !integer, pointer, public :: ntpu_per_grd(:)             ! Number of topounits per grid globally  num_tunits_per_grd
  !integer, pointer, public :: tpu_lnd(:)             ! Number of topounit per grid for the land domain
  !integer, pointer, public :: tpu_glo_ind(:)         ! global index for number of topounits per grid
  !
  ! !PUBLIC MEMBER FUNCTIONS:
  public :: topounit_varcon_init  ! initialize constants in this module
  !-----------------------------------------------------------------------
  
  contains
  
  !-----------------------------------------------------------------------
  subroutine topounit_varcon_init(begg, endg,lfsurdat, ldomain)
    !
    ! !DESCRIPTION:
    ! Initialize topounit parameters
    !
    ! !USES:
    !#py use fileutils   , only : getfil    
    use domainMod , only : domain_type
    !
    ! !ARGUMENTS:
    integer          ,intent(in)    :: begg, endg
    character(len=*), intent(in) :: lfsurdat    ! surface dataset filename
    type(domain_type),intent(in) :: ldomain     ! land domain
    
    !integer , intent(in) :: amask(:)  
    !!integer :: ni
    !!integer :: nj
    !
    ! !LOCAL VARIABLES:
    type(file_desc_t)     :: ncid         ! netcdf id
    integer :: dimid,varid
    integer :: topounits_size                      ! Size of topounit dimension in the surface data 
    character(len=256):: locfn                ! local file name
    logical :: isgrid2d    
    integer :: n,i,j               ! index 
    integer :: ns,ln,lns
    integer :: ni,nj
    integer :: ier                 ! error status
    integer :: numg
    integer :: t
    type(var_desc_t)   :: vardesc  ! variable descriptor
    character(len=256) :: varname  ! variable name
    logical :: readvar             ! read variable in or not
    integer , allocatable :: idata2d(:,:)
    character(len=*), parameter :: subname = 'topounit_varcon_init'
    !-----------------------------------------------------------------------
    
  end subroutine topounit_varcon_init  
end module topounit_varcon
