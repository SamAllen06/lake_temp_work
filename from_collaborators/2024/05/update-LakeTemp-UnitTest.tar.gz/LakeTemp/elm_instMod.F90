module elm_instMod
  use ch4mod, only : ch4_type 
  use atm2lndtype, only : cplbypass_atminput_type 
  use atm2lndtype, only : atm2lnd_type 
  use canopystatetype, only : canopystate_type 
  use energyfluxtype, only : energyflux_type 
  use lnd2atmtype, only : lnd2atm_type 
  use soilhydrologytype, only : soilhydrology_type 
  use lakestatetype, only : lakestate_type 
  use soilstatetype, only : soilstate_type 
  use solarabsorbedtype, only : solarabs_type 
  use cnstatetype, only : cnstate_type 
  implicit none
  save
  public
  type(ch4_type) :: ch4_vars 
  type(cplbypass_atminput_type) :: cpl_bypass_input 
  type(atm2lnd_type) :: atm2lnd_vars 
  type(canopystate_type) :: canopystate_vars 
  type(energyflux_type) :: energyflux_vars 
  type(lnd2atm_type) :: lnd2atm_vars 
  type(soilhydrology_type) :: soilhydrology_vars 
  type(lakestate_type) :: lakestate_vars 
  type(soilstate_type) :: soilstate_vars 
  type(solarabs_type) :: solarabs_vars 
  type(cnstate_type) :: cnstate_vars 
end module elm_instMod
